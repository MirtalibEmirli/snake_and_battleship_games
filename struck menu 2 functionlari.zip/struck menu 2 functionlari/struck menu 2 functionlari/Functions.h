#pragma once
enum direct {
	up = 72,
	down = 80,
	right = 77,
	left = 75,
	enter = 13,
};
void arraywih(int select) {



	char** arrs = new char* [44];
	char* ar1 = new char    [44] {"0.addStudentInGroup"};
	char* ar2 = new char    [44] {"1.ShowStudentScoreGrateThanFiftyInGroup "};
	char* ar3 = new char    [44] {"2. ShowStudentScoreGrateThanFiftyInAcademy"};
	char* ar4 = new char    [44] {"3.ShowStudentold21"};
	char* ar5 = new char    [44] {"4. ShowAcademy"};
	char* ar6 = new char    [44] {"5. ShowGroup"};
	char* ar7 = new char    [44] {"6.ShowStudent"};
	char* ar8 = new char    [44] {"7.AddgroupinAcademy"};

	arrs = new char* [8] {ar1, ar2, ar3, ar4, ar5, ar6, ar7};

	for (size_t i = 0; i < 7; i++)
	{
		if (i == select)
			cout << "\t\t\t" << red << arrs[i] << white << endl;
		else
			cout << "\t\t\t" << white << arrs[i] << endl;
	}

}
void ShowDate(Date* date)
{
	if (date == nullptr)
		return;

	cout << date->Day << "/" << date->Month << "/" << date->Year << endl;
}



// ----------------------------------------
void ShowStudent(Student* student)
{
	if (student == nullptr)
		return;

	cout << "Id: " << (student->Id ? student->Id : -1) << endl;
	cout << "Name: " << (student->Name ? student->Name : "Null") << endl;
	cout << "Surname: " << (student->Surname ? student->Surname : "Null") << endl;
	cout << "City: " << (student->City ? student->City : "Null") << endl;
	cout << "Birth Date: ";	ShowDate(student->BirthDate);
	cout << "Score: " << (student->Score ? student->Score : -1) << endl;

}

// ----------------------------------------------------------------------
void ShowGroup(Group* group)
{
	if (group == nullptr)
		return;


	cout << "\tGroup Name: " << (group->Name ? group->Name : "Null") << endl;
	cout << "Start Date: ";	ShowDate(group->StartDate);

	if (group->StudentSize != 0)
	{
		for (size_t i = 0; i < group->StudentSize; i++)
		{
			ShowStudent(group->Students[i]);
			cout << endl;
		}
	}
	else
	{
		cout << "\t!!! Bu Qrupda Telebe Yoxdur !!!" << endl;
	}

}

// -----------------------------------------------------------------------

void ShowAcademy(Academy* academy)
{
	if (academy == nullptr)
		return;


	cout << "\tAcademy Name: " << (academy->Name ? academy->Name : "Null") << endl;
	cout << "Start Date: ";	ShowDate(academy->StartDate);

	if (academy->GroupSize != 0)
	{
		for (size_t i = 0; i < academy->GroupSize; i++)
		{
			ShowGroup(academy->Groups[i]);
			cout << endl;
		}
	}
	else
	{
		cout << "\t!!! Bu Academy -de Group Yoxdur !!!" << endl;
	}

}


// --------------------------------------=========================================================================================================================================================================

void ShowStudentScoreGrateThanFiftyInGroup(Group* group, int studentSize)
{
	for (size_t i = 0; i < studentSize; i++)
		if (group->Students[i]->Score > 7)
			ShowStudent(group->Students[i]);
}


void ShowStudentScoreGrateThanFiftyInAcademy(Academy* academy, int groupSize)
{
	for (size_t i = 0; i < groupSize; i++)
		ShowStudentScoreGrateThanFiftyInGroup(academy->Groups[i], academy->Groups[i]->StudentSize);
}

void age21(Group*group) {
	for (size_t i = 0; i < group->StudentSize; i++)
	{
		if (group->Students[i]->BirthDate->Day > 17 && group->Students[i]->BirthDate->Day < 22) {
			ShowStudent(group->Students[i]);
		}
	}
}




//8) Student* createStudent()
Student* createstudent(Student* st1){
	 
	st1 = new Student();
	st1->Id;
	st1->City; 
	st1->Score; 
	st1->Surname;   
	st1->Name; 
	st1->BirthDate = new Date();  
	st1->BirthDate->Day;
	st1->BirthDate->Month;
	st1->BirthDate->Year;



	return st1; 
}  



void addStudentInGroup(Student** students, int& StudentSize,Group*&group) {
	Student* st1;
	createstudent(st1);
	cout << "ID daxil edin : ";
	cin >> st1->Id;
	cin.ignore();

	st1->Surname;  
	st1->Name;

	



	cout << "Seher daxil edin ";

	cin.getline(st1->City, 50);


	cout << "Score daxil edin ";

	cin>>st1->Score; 

	st1->BirthDate = new Date();

	cout << "Gun daxil edin ";
	cin >> st1->BirthDate->Day;

	cout << "Ay daxil edin ";
	cin >> st1->BirthDate->Month;


	cout << "IL daxil edin ";
	cin >> st1->BirthDate->Year;
	studentnum++;


	Student** students2 = new Student * [studentnum+1];
	for (size_t i = 0; i < studentnum; i++) 
	{
		students2[i] = students[i];
	}
	students2[studentnum] = st1;
	
	group->Students = students2; 



}



//7) void: addGroupInAcademy(Academy, size, Group)

void addGroupInAcademy(Academy*academy, int groupnum, Group*&group) {  

	Group* newgroup;
	createGroup(newgroup); 

	
	cout << "Grupun NAme ";
	cin.getline(newgroup->Name, 50); 

	cout << "Grupun StartDate i day month year  "; 

	cin>>	newgroup->StartDate->Day;
	cin>>newgroup->StartDate->Month;
	cin>>newgroup->StartDate->Year;

	group = newgroup;


}

//9) Group* createGroup()
Group* createGroup(Group*group) {

    group = new Group();

	group->Name ;

	group->StartDate = new Date();
	group->StartDate->Day ;
	group->StartDate->Month;
	group->StartDate->Year ;

	group->Students = GetStudents();
	group->StudentSize = studentnum;
	return group;
}






//10) Academy* createAcademy()

Academy* createAcademy(Academy*academy) {

	academy = new Academy();


	academy->Name = new char[20] ; 

	academy->StartDate = new Date();

	academy->StartDate->Day ;
	academy->StartDate->Month;
	academy->StartDate->Year ;

	academy->Groups = new Group * [groupnum]; 
	academy->Groups[0] = GetGroups();

	academy->GroupSize = groupnum; 

	return academy;

}





void enter1(int enter, int secim) {
	
	char* ar1 = new char    [44] {"0.addStudentInGroup"};  
	char* ar2 = new char    [44] {"1.ShowStudentScoreGrateThanFiftyInGroup "};
	char* ar3 = new char    [44] {"2. ShowStudentScoreGrateThanFiftyInAcademy"};
	char* ar4 = new char    [44] {"3.ShowStudent old21"};
	char* ar5 = new char    [44] {"4. ShowAcademy"};
	char* ar6 = new char    [44] {"5. ShowGroup"};
	char* ar7 = new char    [44] {"6.ShowStudent"};
	char* ar8 = new char    [44] {"7.AddgroupinAcademy"};
	if (secim == 0) {
		Group* group = GetGroups();
		addStudentInGroup(GetStudents(), studentnum, group); 
	}
	else if(secim==1){
		ShowStudentScoreGrateThanFiftyInGroup(GetGroups(), studentnum); 
}


	else if(secim==2){
		ShowStudentScoreGrateThanFiftyInAcademy(GetAcademy(), groupnum);

	}
	else if(secim==3){
		age21(GetGroups());
			
	}
	else if(secim==4){
		ShowAcademy(GetAcademy());
	}
	else if(secim==5){
		ShowGroup(GetGroups()); 
	}
	else if(secim==6){

		Student** st = GetStudents(); 
		for (size_t i = 0; i < studentnum; i++)
		{
			ShowStudent(st[i]); 

		}
	}
	else if(secim==7){
		Group* groups = GetGroups();
		Academy* academy = GetAcademy();
		addGroupInAcademy(academy, groupnum, groups);
	}


}
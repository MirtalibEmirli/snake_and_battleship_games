#pragma once
int studentnum = 3;
int groupnum= 1;
Student** GetStudents()
{
	Student* st_1 = new Student();

	st_1->Id = 1;
	st_1->Name = new char   [10] {"Ibrahim"};
	st_1->Surname = new char[10] {"Talibli"};
	st_1->City = new char   [10] {"Baku"};
	st_1->Score = 8;

	st_1->BirthDate = new Date(); 
	st_1->BirthDate->Day = 10;
	st_1->BirthDate->Month = 7;
	st_1->BirthDate->Year = 2008;
	// -----------------------------------------------------------------------

	Student* st_2 = new Student();

	st_2->Id = 2; 
	st_2->Name = new char   [20] {"Huseyn"};
	st_2->Surname = new char[20] {"Memmedov"};
	st_2->City = new char   [20] {"Xirdalan"};
	st_2->Score = 6;

	st_2->BirthDate = new Date();
	st_2->BirthDate->Day = 25;
	st_2->BirthDate->Month = 1;
	st_2->BirthDate->Year = 2008;

	// -------------------------------------------------------------------
	Student* st_3 = new Student();

	st_3->Id = 3; 
	st_3->Name = new char   [11] {"Nurlan"};
	st_3->Surname = new char[11] {"Hesenzade"};
	st_3->City = new char   [11] {"Qobu"};
	st_3->Score = 6;

	st_3->BirthDate = new Date();
	st_3->BirthDate->Day = 25;
	st_3->BirthDate->Month = 1;
	st_3->BirthDate->Year = 2008;

	//---------------------------------------------------------------------------

	Student** students = new Student * [studentnum];

	students[0] = st_1;
	students[1] = st_2;
	students[2] = st_3;

	return students;
}


Group* GetGroups()
{
	Group* group = new Group();

	group->Name = new char[20] {"FBAS 1_23_5"};

	group->StartDate = new Date();
	group->StartDate->Day = 15;
	group->StartDate->Month = 5;
	group->StartDate->Year = 2023;

	group->Students = GetStudents(); 
	group->StudentSize = studentnum;

	return group;
}


Academy* GetAcademy()
{
	Academy* academy = new Academy();

	academy->Name = new char[20] {"Step It Academy"};

	academy->StartDate = new Date();

	academy->StartDate->Day = 28;
	academy->StartDate->Month = 11;
	academy->StartDate->Year = 2019;

	academy->Groups = new Group * [1];
	academy->Groups[0] = GetGroups();

	academy->GroupSize = groupnum;

	return academy;
}


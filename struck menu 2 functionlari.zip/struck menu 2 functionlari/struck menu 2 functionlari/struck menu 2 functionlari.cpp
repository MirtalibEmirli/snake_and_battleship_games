//default konstruktorun 4 silinme yolu var 
//1.Yeni parametrli  konstruktor yaratmaq
//2.Default konstruktoru private edmek 
//struct Student {
//private :
//	Student() {
//
//	}
//};

//3.Default konstruktoru delete ederek 
//struct Student {
//private :
//	Student()  =delete ; 
//
//	
//};

 /*
#if 15< 2
	int a;
#endif
///////std::cout <<*/ //a;.

/*cout << setw(40) <<left<< setfill('-') << "Salam" << endl;
//*///cout << setw(40) <<right<< setfill('-') << "Salam" << endl;



#include <iostream>
#include <conio.h>
#include "MyTypes.h"
#include "SeedData.h" 
#include "Functions.h" 

using namespace std;

int main()
{
	

	int select = 0; 
	while (true) {
		int num = _getch();
		if (num == 224) {
			num = _getch();

			if (num == up) {
				if (select == 7 || select == 6 || select == 5 || select == 4 || select == 3 || select == 2 || select == 1) {
					select--;
				}
				else if (select == 0)
					select = 7;
			}
			else if (num == down) {
				if (select == 0 || select == 6 || select == 5 || select == 4 || select == 3 || select == 2 || select == 1) {
					select++;
				}
				else if (select == 7)
					select = 0;
			}

			if (num == 13) {

			}
			system("cls");
			arraywih(select);

		}
	}
	








}
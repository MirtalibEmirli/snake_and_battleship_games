#pragma once
#define red " \033[31m"
#define white "\033[37m"
#define green "\x1B[32m"
#define purple "\x1B[35m"
struct Date
{
	short int Day = 1;
	short int Month = 2;
	short int Year = 3;
};

struct Student
{
	int Id = 0;  
	char* Name = nullptr; 
	char* Surname = nullptr;
	char* City = nullptr;
	Date* BirthDate = nullptr;
	float Score = 0;
};

struct Group
{
	char* Name = nullptr;
	Date* StartDate = nullptr;
	Student** Students = nullptr;
	int StudentSize = 0;
};

struct Academy
{
	char* Name = nullptr;
	Date* StartDate = nullptr;
	Group** Groups = nullptr;
	int GroupSize = 0;
};